@extends('layouts.app')

@section('content')
    <privasi></privasi> 
@endsection
