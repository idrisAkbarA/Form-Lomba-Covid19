@extends('layouts.app')

@section('content')
    <poster-upload></poster-upload> 
@endsection
