@extends('layouts.app')

@section('content')
    <peserta></peserta> 
@endsection