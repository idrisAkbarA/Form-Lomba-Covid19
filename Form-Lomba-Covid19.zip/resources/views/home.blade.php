@extends('layouts.app')

@section('content')
    <landing></landing> 
@endsection
