@extends('layouts.app')

@section('content')
    <video-upload></video-upload> 
@endsection
