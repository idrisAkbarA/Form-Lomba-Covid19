@extends('layouts.app')

@section('content')
    <takeoff></takeoff> 
@endsection