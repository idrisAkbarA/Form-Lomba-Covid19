<template>
  <div>
    <v-container
      fill-height
      fluid
    >
      <v-row>
        <v-col cols="12">
          <v-card elevation="20">
            <v-img
              class="white--text align-end"
              height="200px"
              src="images/video.png"
            ></v-img>
            <v-card-title>
              Kebijakan Privasi Pengguna
            </v-card-title>
            <v-container>
              <v-row>
                  <v-col cols="12">
                <p>
                    Adapun berikut kebijakan privasi untuk aplikasi ini
                </p>
                    <li>Aplikasi ini dapat menyimpan file (video/gambar) karya peserta lomba di penyimpanan google drive peserta itu sendiri</li>
                    <li>Aplikasi ini hanya dapat memiliki link download file karya yang telah diupload pengguna</li>
                    <li>Aplikasi ini tidak mengambil data-data peserta selain file karya lomba cegah corona virus yang peserta unggah</li>

                  </v-col>
            
              </v-row>
            </v-container>
          </v-card>
        </v-col>
      </v-row>

    </v-container>
  </div>
</template>
<script>
export default {
    
}
</script>